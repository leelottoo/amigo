package com.keduit.amigo.constant;

public enum Gender {
    남자, 여자
}
