package com.keduit.amigo.entity;

import com.keduit.amigo.constant.Gender;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
@ToString
@Table(name = "director")
public class Director {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "director_id")
    private Long directorId;

    @Column(name = "name")
    private String name;

    @Column(name = "birthdate")
    private String birthdate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "nationality")
    private Country nationality;

    @Column(name = "gender")
    @Enumerated(EnumType.STRING)
    private Gender gender;

    @Column(name = "debut")
    private String debut;

    @Column(name = "filmography")
    private String filmography;

    @OneToMany(mappedBy = "directorId", fetch = FetchType.LAZY)
    private List<Movie> directors;
}
