package com.keduit.amigo.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@ToString
@Table(name = "movie")
public class Movie {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "movie_id")
    private Long movieId;

    @Column(name = "title")
    private String title;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "genre_id")
    private Genre genreId;

    @Column(name = "running_time")
    private int runningTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "country_id")
    private Country countryId;

    @Column(name = "release_date")
    private Date releaseDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "director_id")
    private Director directorId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "additional_info_id")
    private AdditionalInfo additionalInfoId;

    @ElementCollection
    @Column(name = "actor")
    private List<String> actor;

    @OneToMany(mappedBy = "reviewId", fetch = FetchType.LAZY)
    private List<Review> reviews;
}
