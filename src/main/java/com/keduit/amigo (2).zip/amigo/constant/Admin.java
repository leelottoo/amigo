package com.keduit.amigo.constant;

public enum Admin {
    일반회원, 관리자
}
