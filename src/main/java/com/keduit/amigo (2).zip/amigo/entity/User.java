package com.keduit.amigo.entity;

import com.keduit.amigo.constant.Admin;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@ToString
@Table(name = "user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long userId;

    @Column(name = "email", unique = true, nullable = false)
    private String email;

    @Column(name = "pwd", nullable = false)
    private String pwd;

    @Column(name = "username", unique = true, nullable = false)
    private String userName;

    @Column(name = "join_date")
    private Date joinDate;

    @Column(name = "admin")
    @Enumerated(EnumType.STRING)
    private Admin admin;

    @OneToMany(mappedBy = "userId", fetch = FetchType.LAZY)
    private List<UserActivity> activities;

    @OneToMany(mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Review> reviews;
}
