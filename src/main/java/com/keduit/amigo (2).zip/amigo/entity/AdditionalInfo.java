package com.keduit.amigo.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
@ToString
@Table(name = "additional_info")
public class AdditionalInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "activity_id")
    private Long activityId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "rating_id")
    private Rating ratingId;

    @Column(name = "score", precision = 3, scale = 1)
    private Double score;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id")
    private ProductionCompany companyId;

    @Column(name = "trailer_link")
    private String trailerLink;

    @Column(name = "poster_image")
    private String posterImage;

    @OneToMany(mappedBy = "additionalInfoId", fetch = FetchType.LAZY)
    private List<Movie> additionalInfos;
}
